Asynchronous Socket Server Sample
=================================

     This sample demonstrates how to use the xxxAsync (xxx = receive, send, connect, etc) methods on the Sytem.Net.Sockets.Socket 
     class by implementing an echo server (ie. The server sends all the data read from a client back to the client).  
     The echo server implemented in this sample handles multiple clients simultaneously (up to a maximum specified as a command line argument)
     and highlights some of the key elements of the event-based asynchronous socket methods.
     The sample illustrates creating a pool of reusable data buffers and SocketAsyncEventArgs context objects as a method to
     increase server performance.             

     The sample is intended for educational purposes and should not be used directly in production applications.     

 

Sample Language Implementations
===============================
     This sample is available in the following language implementations: 
     C# 

Prerequisites
=============
     This sample requires the .NET Framework v4.0

 

Building the Sample
===================
     To build the sample using Visual Studio (preferred method):

     1. Double-click the AsyncSocketServer.sln file to open the socket server sample in Visual Studio.

     2. Using the menu, click Build > Build Solution.
 

     To build the sample using the command prompt:

     1. Open the Command Prompt window and navigate to the directory containing the socket server sample.

     2. Type msbuild AsyncSocketServer.sln.


Running the Sample
==================
     The socket server requires four command line parameters.


     Usage: 

     AsyncSocketServer.exe <#connections> <Receive Size In Bytes> <address family: ipv4 | ipv6> <localPortNum>

 

     # Connections: The maximum number of connections the server will accept simultaneously.

     Receive Size in Bytes: The buffer size used by the server for each receive operation.  

     Address family: The address family of the socket the server will use to listen for incoming connections.  Supported values are �ipv4� and �ipv6�.

     Local Port Number: The port to which the server will bind.

 

     Example: 

     AsyncSocketServer.exe 500 1024 ipv4 8000
