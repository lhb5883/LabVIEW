/*****************************************************************************/
/* Includes                                                                  */
/*****************************************************************************/
#include "TrayIcon.h"

/******************************************************************************/
/* ActiveX server's WinMain function                      				      */
/******************************************************************************/
int __stdcall WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                       LPSTR lpszCmdLine, int nCmdShow)
{
	// Variables for error checking macros: errChk, nullChk and hrChk
	int 	   error = 0;
    HRESULT    hr = S_OK;
    HWND	   hWnd = 0;
	
	// Local Variables
	int        runServer = 0;		// Server Running Flag
	char       errBuf [500] = {0};  // Error buffer
	int        initedServer = 0;    // Server created flag

	// Hide Server Window.
	hWnd = FindWindow(NULL,"Tray Icon ActiveX Server");
	ShowWindow(hWnd, SW_HIDE);
	
	nullChk (InitCVIRTE (hInstance, 0, 0))

    // Intialize locks and data structures
    errChk (CmtNewLock ("", 0, &gObjListLock));
    nullChk (gObjList = ListCreate (sizeof (CAServerObjHandle)));
    
	// ActiveX server initialization
	hrChk (CaSrvraxsTrayIconInit (hInstance, lpszCmdLine, &runServer, errBuf, 
							   		 sizeof(errBuf)));
    initedServer = 1;

	if (runServer)
	{
		errChk (RunUserInterface ());	// Process messages
	}

Error:
	// ActiveX server cleanup
    if (initedServer)
		CaSrvraxsTrayIconUninit (hInstance);
    
    // Discard List Lock
    if (gObjListLock)
        CmtDiscardLock (gObjListLock);
    
    // Dispose Server Object List
    if (gObjList)
        ListDispose (gObjList);
    
	if (panelHandle)
		DiscardPanel (panelHandle);

    // Set error if windows error occured.
    if (FAILED (hr))
        error = -1;

	return error;
}

/******************************************************************************/
/* ActiveX Server Callback Function                                           */
/*                                                                            */
/* Events:                                                                    */
/* 1) CA_SERVER_EVENT_MODULE_EXIT                                             */
/*                                                                            */
/* MUST BE IMPLEMENTED BY USER IN USER'S SOURCE CODE                          */
/******************************************************************************/

int CVIFUNC TrayIconServerCB (int event)
{
	switch (event)
		{
		case CA_SERVER_EVENT_MODULE_EXIT:
			
			break;
		default:
			
			break;
		}
		
	// Return 0 to exit the User Interface Loop.
	return 0;
}


/******************************************************************************/
/* ActiveX Object Callback Function(s)                                        */
/*                                                                            */
/* Events:                                                                    */
/* 1) CA_SERVER_EVENT_OBJECT_CREATE                                           */
/* 2) CA_SERVER_EVENT_OBJECT_DESTROY                                          */
/******************************************************************************/

HRESULT CVIFUNC TrayIconObjectCB (CAServerObjHandle objHandle,
                                  const CLSID *pClsid, int event,
                                  void *callbackData)
{
	// Variables for error checking macros: errChk, nullChk and hrChk
	int 	   error = 0;
    HRESULT    hr = S_OK;
    
	// Local Variables
    TrayIconObjData   *pObjData = NULL;
    int               objIndex;
	int 			  locked = 0;

	switch (event)
	{
		case CA_SERVER_EVENT_OBJECT_CREATE:
        
	        // Allocate object data
	        nullChk (pObjData = malloc (sizeof (TrayIconObjData)));
	        nullChk (memset(pObjData, 0, sizeof (TrayIconObjData)));
	        nullChk (pObjData->MenuItems = ListCreate (sizeof (TrayIconMenuItem)));

	        hrChk (CA_ServerSetObjData (objHandle, pObjData));
        
	        // Store the object in object list
	        errChk (CmtGetLock (gObjListLock));
	        locked = 1;
	        nullChk (ListInsertItem (gObjList, &objHandle, END_OF_LIST));
	        pObjData = NULL;
	        
			break;
		case CA_SERVER_EVENT_OBJECT_DESTROY:
        
	        // Get the object data and dispose it
	        hrChk (CA_ServerGetObjData (objHandle, &pObjData));
	        if (pObjData)
	        {	
				DetachTrayIconMenu (pObjData->iconHandle); 
				RemoveSysTrayIcon (pObjData->iconHandle);
				ListDispose (pObjData->MenuItems);
	        	free (pObjData);
	        }
	        hrChk (CA_ServerReleaseObjData (objHandle));
        
	        // Remove the object from the object list
	        errChk (CmtGetLock (gObjListLock));
	        locked = 1;
	        objIndex = ListFindItem (gObjList, &objHandle, FRONT_OF_LIST, IntCompare);
	        if (objIndex) ListRemoveItem (gObjList, NULL, objIndex);
		
			break;
		default:
		
			break;
	}
	
Error:
    if (locked)
        CmtReleaseLock (gObjListLock);
    if (error < 0)
        hr = E_UNEXPECTED;
    return hr;
}

/*****************************************************************************/
/* TrayIcon Callback Function                                                */
/*****************************************************************************/
int CVICALLBACK TrayIconCB (int iconHandle, int event, int eventData)
{
	// Variables for error checking macros: errChk, nullChk and hrChk
	int 	   error = 0;
    HRESULT    hr = S_OK;

    int                 locked = 0;
    int                 objLocked = 0;
    int                 releaseEventObjs = 0;
    TrayIconObjData     *pObjData = NULL;
    CAServerObjHandle   objHandle = 0;
    CAObjHandle         eventObjs[CA_SERVER_MAX_EVENT_CONNECTIONS];
    unsigned int        numEventObjs = 0;
    int                 i, j, numObjs;
    
    // Iterate through the objects in the object list
    errChk (CmtGetLock (gObjListLock));
    locked = 1;
    numObjs = ListNumItems (gObjList);
    for (i = 1; i <= numObjs; ++i) 
    {
    	// Get Object i
        ListGetItem (gObjList, &objHandle, i);
        hrChk (CA_ServerGetObjData (objHandle, &pObjData));
        objLocked = 1;
        
        // Check if any event occured for this server object
        if (pObjData->iconHandle == iconHandle && pObjData->iconInstalled) 
        {
            // Event occurred. Get all registered client event objects.
            CA_ServerGetEventObjHandles (objHandle, &IID_ITrayIconEvents,
                0, LOCALE_NEUTRAL, eventObjs, &numEventObjs);
            releaseEventObjs = 1;
            // On each client event object registered for this server object,
            // fire the event that occurred.
            for (j = 0; j < numEventObjs; ++j) 
            {
                // skip if eventObj invalid
                if (eventObjs[j] != 0)
                {
				    switch (event)
			        {
				        case EVENT_LEFT_CLICK:
				            TrayIconITrayIconEventsLeftClick (eventObjs[j], NULL);
				            break;
				        case EVENT_LEFT_MOUSE_UP:
				            TrayIconITrayIconEventsLeftMouseButtonUp (eventObjs[j], NULL);
				            break;
				        case EVENT_RIGHT_CLICK:
				            TrayIconITrayIconEventsRichtClick (eventObjs[j], NULL);
				            break;
				        case EVENT_RIGHT_MOUSE_UP:
				            TrayIconITrayIconEventsRightMouseButtonUp (eventObjs[j], NULL);
				            break;
				        case EVENT_LEFT_DOUBLE_CLICK:
				            TrayIconITrayIconEventsLeftDoubleClick (eventObjs[j], NULL);
				            break;
				        case EVENT_RIGHT_DOUBLE_CLICK:        
				            TrayIconITrayIconEventsRightDoubleClick (eventObjs[j], NULL);
				            break;
				        case EVENT_MENU_ITEM:
				            /* With menu events, eventData contains the selected item's ID */
				            // Make interface index 0 based
				            TrayIconITrayIconEventsMenuItemSelected (eventObjs[j], NULL, eventData - 1);
				            break;
				        default:
				        	break;
			        }
				}
            }
            // Release this server object's client event objects
            hrChk (CA_ServerReleaseEventObjHandles (objHandle, 
                &IID_ITrayIconEvents, eventObjs));
            releaseEventObjs = 0;
    	}
        hrChk (CA_ServerReleaseObjData (objHandle));
        objLocked = 0;
        objHandle = 0;
    }

Error:
    if (objHandle) 
    {
        if (releaseEventObjs)
            CA_ServerReleaseEventObjHandles (objHandle, 
                &IID_ITrayIconEvents, eventObjs);
                
        if (objLocked)
            CA_ServerReleaseObjData (objHandle);
    }
    if (locked)
        CmtReleaseLock (gObjListLock);
    
    /* Honor our popup menu -- return non-zero to prevent popup from appearing */
    return 0;
}

/*****************************************************************************/
/* Functions                                                                 */
/*****************************************************************************/
int BuildMenu(TrayIconObjData objData)
{
	int					error = 0;
	int					i,index, numItems = 0;	
	TrayIconMenuItem	item;
	
	if (objData.iconInstalled)
	{	
		AttachTrayIconMenu (objData.iconHandle);
		numItems = ListNumItems(objData.MenuItems);
		for (i = 1; i <= numItems; i++)
		{
			ListGetItem (objData.MenuItems, &item, i);
			
			errChk(InsertTrayIconMenuItem (objData.iconHandle, 
										   item.Name, &index));
			errChk(SetTrayIconMenuItemAttr (objData.iconHandle, 
											index, ATTR_DIMMED, item.Dimmed));
			errChk(SetTrayIconMenuItemAttr (objData.iconHandle, 
											index, ATTR_CHECKED, item.Checked));
		}
		errChk(SetTrayIconMenuAttr (objData.iconHandle, ATTR_POPUP_DEFAULT_ITEM,
									objData.defaultMenuItem));
		errChk(SetTrayIconMenuAttr (objData.iconHandle, ATTR_VISIBLE,
									objData.menuVisable));

	}
Error:

	return error;
}

char *dupStr(char *str)
{
	char *dup;
	
	dup = malloc (sizeof(char) * (strlen(str) + 1));
	strcpy(dup, str);
	return dup; 
}



















