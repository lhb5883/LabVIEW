/******************************************************************************/
/* WARNING: LabWindows/CVI generates this file. Do not add to, delete from,   */
/*          or otherwise modify the contents of this file.                    */
/******************************************************************************/

#include "TrayIconActiveXServer_axs.h"

/******************************************************************************/
/* Const Definitions of GUIDs                                                 */
/******************************************************************************/

const GUID LIBID_axsTrayIcon = {0x707165C1, 0x18B, 0x4682, 0x84, 0x3C,
                                0xCE, 0x64, 0x34, 0xA8, 0x37, 0x11};
const GUID CLSID_TrayIcon = {0xD4D2422E, 0xE258, 0x41AD, 0xB6, 0xB1, 0x53,
                             0x1D, 0xCF, 0x73, 0x2, 0xDF};
const GUID IID_ITrayIcon = {0x8E916F8C, 0x2C57, 0x4A36, 0x9B, 0xD1, 0x96,
                            0x30, 0x1D, 0x2, 0x60, 0x99};
const GUID IID_ITrayIconEvents = {0xE73D4917, 0x818C, 0x4237, 0xAC, 0x8D,
                                  0xD, 0x32, 0x10, 0xB5, 0xB6, 0x7D};

/******************************************************************************/
/* Definitions of interface methods                                           */
/******************************************************************************/

static STDMETHODIMP CaSrvrTrayIconITrayIconget_IconImageFile (ITrayIcon* This,
                                                              BSTR* IconImageFile)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;
	BSTR IconImageFile__AutoType = 0;
	char * __IconImageFile = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));

	*IconImageFile = NULL;

	__caErrChk (TrayIconITrayIconget_IconImageFile (objHandle, &__IconImageFile));


	__caErrChk (CA_CStringToBSTR (__IconImageFile, &IconImageFile__AutoType));


	*IconImageFile = IconImageFile__AutoType;

	IconImageFile__AutoType = 0;

Error:
	CA_FreeBSTR (IconImageFile__AutoType);
	CA_FreeMemory (__IconImageFile);
	return __result;
}

static STDMETHODIMP CaSrvrTrayIconITrayIconput_IconImageFile (ITrayIcon* This,
                                                              BSTR IconImageFile)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;
	char * __IconImageFile = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));

	if (IconImageFile)
		__caErrChk (CA_BSTRGetCString (IconImageFile, &__IconImageFile));

	__caErrChk (TrayIconITrayIconput_IconImageFile (objHandle, __IconImageFile));

Error:
	CA_FreeMemory (__IconImageFile);
	return __result;
}

static STDMETHODIMP CaSrvrTrayIconITrayIconget_ToolTipText (ITrayIcon* This,
                                                            BSTR* ToolTipText)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;
	BSTR ToolTipText__AutoType = 0;
	char * __ToolTipText = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));

	*ToolTipText = NULL;

	__caErrChk (TrayIconITrayIconget_ToolTipText (objHandle, &__ToolTipText));


	__caErrChk (CA_CStringToBSTR (__ToolTipText, &ToolTipText__AutoType));


	*ToolTipText = ToolTipText__AutoType;

	ToolTipText__AutoType = 0;

Error:
	CA_FreeBSTR (ToolTipText__AutoType);
	CA_FreeMemory (__ToolTipText);
	return __result;
}

static STDMETHODIMP CaSrvrTrayIconITrayIconput_ToolTipText (ITrayIcon* This,
                                                            BSTR ToolTipText)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;
	char * __ToolTipText = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));

	if (ToolTipText)
		__caErrChk (CA_BSTRGetCString (ToolTipText, &__ToolTipText));

	__caErrChk (TrayIconITrayIconput_ToolTipText (objHandle, __ToolTipText));

Error:
	CA_FreeMemory (__ToolTipText);
	return __result;
}

static STDMETHODIMP CaSrvrTrayIconITrayIconget_MenuVisable (ITrayIcon* This,
                                                            VARIANT_BOOL* MenuVisable)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));
	__caErrChk (TrayIconITrayIconget_MenuVisable (objHandle, MenuVisable));

Error:
	return __result;
}

static STDMETHODIMP CaSrvrTrayIconITrayIconput_MenuVisable (ITrayIcon* This,
                                                            VARIANT_BOOL MenuVisable)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));
	__caErrChk (TrayIconITrayIconput_MenuVisable (objHandle, MenuVisable));

Error:
	return __result;
}

static STDMETHODIMP CaSrvrTrayIconITrayIconget_DefaultMenuItem (ITrayIcon* This,
                                                                long* DefaultMenuItem)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));
	__caErrChk (TrayIconITrayIconget_DefaultMenuItem (objHandle, DefaultMenuItem));

Error:
	return __result;
}

static STDMETHODIMP CaSrvrTrayIconITrayIconput_DefaultMenuItem (ITrayIcon* This,
                                                                long DefaultMenuItem)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));
	__caErrChk (TrayIconITrayIconput_DefaultMenuItem (objHandle, DefaultMenuItem));

Error:
	return __result;
}

static STDMETHODIMP CaSrvrTrayIconITrayIconget_NumberOfMenuItems (ITrayIcon* This,
                                                                  short* NumberOfMenuItems)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));
	__caErrChk (TrayIconITrayIconget_NumberOfMenuItems (objHandle,
	                                                    NumberOfMenuItems));

Error:
	return __result;
}

static STDMETHODIMP CaSrvrTrayIconITrayIconInstallTrayIcon (ITrayIcon* This)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));
	__caErrChk (TrayIconITrayIconInstallTrayIcon (objHandle));

Error:
	return __result;
}

static STDMETHODIMP CaSrvrTrayIconITrayIconInstallTrayIconAdvanced (ITrayIcon* This,
                                                                    BSTR IconImageFile,
                                                                    BSTR ToolTipText)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;
	char * __IconImageFile = 0;
	char * __ToolTipText = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));

	if (IconImageFile)
		__caErrChk (CA_BSTRGetCString (IconImageFile, &__IconImageFile));

	if (ToolTipText)
		__caErrChk (CA_BSTRGetCString (ToolTipText, &__ToolTipText));

	__caErrChk (TrayIconITrayIconInstallTrayIconAdvanced (objHandle,
	                                                      __IconImageFile,
	                                                      __ToolTipText));

Error:
	CA_FreeMemory (__IconImageFile);
	CA_FreeMemory (__ToolTipText);
	return __result;
}

static STDMETHODIMP CaSrvrTrayIconITrayIconRemoveTrayIcon (ITrayIcon* This)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));
	__caErrChk (TrayIconITrayIconRemoveTrayIcon (objHandle));

Error:
	return __result;
}

static STDMETHODIMP CaSrvrTrayIconITrayIconAddMenuItem (ITrayIcon* This,
                                                        BSTR Name,
                                                        VARIANT_BOOL Dimmed,
                                                        VARIANT_BOOL Checked)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;
	char * __Name = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));

	if (Name)
		__caErrChk (CA_BSTRGetCString (Name, &__Name));

	__caErrChk (TrayIconITrayIconAddMenuItem (objHandle, __Name, Dimmed, Checked));

Error:
	CA_FreeMemory (__Name);
	return __result;
}

static STDMETHODIMP CaSrvrTrayIconITrayIconGetMenuItem (ITrayIcon* This,
                                                        short Index, BSTR* Name,
                                                        VARIANT_BOOL* Dimmed,
                                                        VARIANT_BOOL* Checked)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;
	BSTR Name__AutoType = 0;
	char * __Name = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));

	*Name = NULL;

	__caErrChk (TrayIconITrayIconGetMenuItem (objHandle, Index, &__Name, Dimmed,
	                                          Checked));


	__caErrChk (CA_CStringToBSTR (__Name, &Name__AutoType));


	*Name = Name__AutoType;

	Name__AutoType = 0;

Error:
	CA_FreeBSTR (Name__AutoType);
	CA_FreeMemory (__Name);
	return __result;
}

static STDMETHODIMP CaSrvrTrayIconITrayIconReplaceMenuItem (ITrayIcon* This,
                                                            short Index,
                                                            BSTR Name,
                                                            VARIANT_BOOL Dimmed,
                                                            VARIANT_BOOL Checked)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;
	char * __Name = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));

	if (Name)
		__caErrChk (CA_BSTRGetCString (Name, &__Name));

	__caErrChk (TrayIconITrayIconReplaceMenuItem (objHandle, Index, __Name,
	                                              Dimmed, Checked));

Error:
	CA_FreeMemory (__Name);
	return __result;
}

static STDMETHODIMP CaSrvrTrayIconITrayIconDeleteMenuItem (ITrayIcon* This,
                                                           short Index)
{
	CAServerObjHandle objHandle = 0;
	HRESULT __result = 0;

	__caErrChk (CA_ServerGetObjHandleFromIface (This, &objHandle));
	__caErrChk (TrayIconITrayIconDeleteMenuItem (objHandle, Index));

Error:
	return __result;
}

/******************************************************************************/
/* Definitions of user's ActiveX event wrapper functions                      */
/******************************************************************************/

HRESULT CVIFUNC TrayIconITrayIconEventsLeftClick (CAObjHandle eventObjHandle,
                                                  ERRORINFO* errorInfo)
{
	HRESULT __result = 0;

	__caErrChk (CA_MethodInvokeEx (eventObjHandle, errorInfo,
	                               &IID_ITrayIconEvents, 1, CAVT_EMPTY, 0, 0, 0));

Error:
	return __result;
}

HRESULT CVIFUNC TrayIconITrayIconEventsLeftDoubleClick (CAObjHandle eventObjHandle,
                                                        ERRORINFO* errorInfo)
{
	HRESULT __result = 0;

	__caErrChk (CA_MethodInvokeEx (eventObjHandle, errorInfo,
	                               &IID_ITrayIconEvents, 3, CAVT_EMPTY, 0, 0, 0));

Error:
	return __result;
}

HRESULT CVIFUNC TrayIconITrayIconEventsLeftMouseButtonUp (CAObjHandle eventObjHandle,
                                                          ERRORINFO* errorInfo)
{
	HRESULT __result = 0;

	__caErrChk (CA_MethodInvokeEx (eventObjHandle, errorInfo,
	                               &IID_ITrayIconEvents, 5, CAVT_EMPTY, 0, 0, 0));

Error:
	return __result;
}

HRESULT CVIFUNC TrayIconITrayIconEventsMenuItemSelected (CAObjHandle eventObjHandle,
                                                         ERRORINFO* errorInfo,
                                                         short ItemIndex)
{
	HRESULT __result = 0;
	unsigned int __paramTypes[] = {CAVT_SHORT};

	__caErrChk (CA_MethodInvokeEx (eventObjHandle, errorInfo,
	                               &IID_ITrayIconEvents, 7, CAVT_EMPTY, 0, 1,
	                               __paramTypes, ItemIndex));

Error:
	return __result;
}

HRESULT CVIFUNC TrayIconITrayIconEventsRichtClick (CAObjHandle eventObjHandle,
                                                   ERRORINFO* errorInfo)
{
	HRESULT __result = 0;

	__caErrChk (CA_MethodInvokeEx (eventObjHandle, errorInfo,
	                               &IID_ITrayIconEvents, 2, CAVT_EMPTY, 0, 0, 0));

Error:
	return __result;
}

HRESULT CVIFUNC TrayIconITrayIconEventsRightDoubleClick (CAObjHandle eventObjHandle,
                                                         ERRORINFO* errorInfo)
{
	HRESULT __result = 0;

	__caErrChk (CA_MethodInvokeEx (eventObjHandle, errorInfo,
	                               &IID_ITrayIconEvents, 4, CAVT_EMPTY, 0, 0, 0));

Error:
	return __result;
}

HRESULT CVIFUNC TrayIconITrayIconEventsRightMouseButtonUp (CAObjHandle eventObjHandle,
                                                           ERRORINFO* errorInfo)
{
	HRESULT __result = 0;

	__caErrChk (CA_MethodInvokeEx (eventObjHandle, errorInfo,
	                               &IID_ITrayIconEvents, 6, CAVT_EMPTY, 0, 0, 0));

Error:
	return __result;
}


/******************************************************************************/
/* Definitions of CVI ActiveX Server API structures                           */
/******************************************************************************/

static void * TrayIconITrayIconFuncArr[] =
	{
		(void *)CaSrvrTrayIconITrayIconget_IconImageFile,
        (void *)CaSrvrTrayIconITrayIconput_IconImageFile,
        (void *)CaSrvrTrayIconITrayIconget_ToolTipText,
        (void *)CaSrvrTrayIconITrayIconput_ToolTipText,
        (void *)CaSrvrTrayIconITrayIconget_MenuVisable,
        (void *)CaSrvrTrayIconITrayIconput_MenuVisable,
        (void *)CaSrvrTrayIconITrayIconget_DefaultMenuItem,
        (void *)CaSrvrTrayIconITrayIconput_DefaultMenuItem,
        (void *)CaSrvrTrayIconITrayIconget_NumberOfMenuItems,
        (void *)CaSrvrTrayIconITrayIconInstallTrayIcon,
        (void *)CaSrvrTrayIconITrayIconInstallTrayIconAdvanced,
        (void *)CaSrvrTrayIconITrayIconRemoveTrayIcon,
        (void *)CaSrvrTrayIconITrayIconAddMenuItem,
        (void *)CaSrvrTrayIconITrayIconGetMenuItem,
        (void *)CaSrvrTrayIconITrayIconReplaceMenuItem,
        (void *)CaSrvrTrayIconITrayIconDeleteMenuItem
	};

static CAServerUserVtbl TrayIconITrayIconVtbl =
	{
		sizeof(TrayIconITrayIconFuncArr)/sizeof(TrayIconITrayIconFuncArr[0]),
        (void **)&TrayIconITrayIconFuncArr
	};

static CAServerDispatchDesc TrayIconITrayIconDispatchDesc =
	{
		0,
        &LIBID_axsTrayIcon,
        1,
        0,
        1
	};

static CAServerIfaceDesc TrayIconITrayIconIfaceDesc =
	{
		IfaceType_kIDispatchDerived,
        &TrayIconITrayIconVtbl,
        &IID_ITrayIcon,
        &TrayIconITrayIconDispatchDesc
	};

static CAServerDispatchDesc TrayIconITrayIconEventsDispatchDesc =
	{
		0,
        &LIBID_axsTrayIcon,
        1,
        0,
        0
	};

static CAServerIfaceDesc TrayIconITrayIconEventsIfaceDesc =
	{
		IfaceType_kEvent,
        0,
        &IID_ITrayIconEvents,
        &TrayIconITrayIconEventsDispatchDesc
	};

static CAServerIfaceDesc * TrayIconIfaceDescList[] =
	{
		&TrayIconITrayIconIfaceDesc,
        &TrayIconITrayIconEventsIfaceDesc
	};

static CAServerObjDesc TrayIconObjDesc =
	{
		"axsTrayIcon.TrayIcon",
        1,
        &CLSID_TrayIcon,
        "Tray Icon Object",
        0,
        ServerObjType_SingleDocApplication,
        1,
        0,
        0,
        TrayIconObjectCB,
        sizeof(TrayIconIfaceDescList)/sizeof(TrayIconIfaceDescList[0]),
        TrayIconIfaceDescList
	};

static CAServerObjDesc * axsTrayIconObjDescList[] =
	{
		&TrayIconObjDesc
	};

static CAServerTypeLibDesc axsTrayIconTypeLibDesc =
	{
		&LIBID_axsTrayIcon,
        1,
        0,
        0,
        SYS_WIN32
	};

static CAServerModuleDesc axsTrayIconModuleDesc =
	{
		ThreadingModel_Single,
        DllMultiThreadingModel_None,
        0,
        TrayIconServerCB,
        sizeof(axsTrayIconObjDescList)/sizeof(axsTrayIconObjDescList[0]),
        axsTrayIconObjDescList,
        &axsTrayIconTypeLibDesc
	};


/******************************************************************************/
/* Definitions of functions and variables related to the server module        */
/******************************************************************************/

STDMETHODIMP CaSrvraxsTrayIconInit (
             	HINSTANCE hinst, char *cmdLine, int *runServer,
             	char *errStrBuf, int bufSize)
{
	return CA_InitActiveXServer (hinst, kServerModuleType_Exe, cmdLine,
	                             &axsTrayIconModuleDesc,
	                             runServer, errStrBuf, bufSize);
}

STDMETHODIMP CaSrvraxsTrayIconUninit (HINSTANCE hinst)
{
	return CA_CloseActiveXServer (hinst);
}
