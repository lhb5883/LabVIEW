/*****************************************************************************/
/* Includes                                                                  */
/*****************************************************************************/
#include "TrayIcon.h"

/*****************************************************************************/
/* ActiveX ITrayIcon interface implementation                                */
/*****************************************************************************/
HRESULT CVIFUNC TrayIconITrayIconInstallTrayIconAdvanced (CAServerObjHandle objHandle,
                                                  		  char * IconImageFile,
                                                  		  char * ToolTipText)
{
    int 				error = 0;
    HRESULT             hr = S_OK;
    TrayIconObjData     *pObjData = NULL;
    int                 locked = 0;

    // Get the object data.
    hrChk (CA_ServerGetObjData (objHandle, &pObjData));
    locked = 1;
    pObjData->IconImageFile = dupStr(IconImageFile);
    pObjData->ToolTipText = dupStr(ToolTipText);
    hrChk(CA_ServerReleaseObjData (objHandle));
    locked = 0;

	hrChk(TrayIconITrayIconInstallTrayIcon(objHandle));

Error:
    if (locked)
        CA_ServerReleaseObjData (objHandle);
    if (error < 0)
        hr = E_UNEXPECTED;
    return hr;
}

HRESULT CVIFUNC TrayIconITrayIconInstallTrayIcon (CAServerObjHandle objHandle)
{
    int 				error = 0;
    HRESULT             hr = S_OK;
    TrayIconObjData     *pObjData = NULL;
    int                 locked = 0;

    // Get the object data.
    hrChk (CA_ServerGetObjData (objHandle, &pObjData));
    locked = 1;
    
    if (!pObjData->iconInstalled)
    {
    	// Add an icon to the taskbar System Tray
   		errChk(InstallSysTrayIcon (pObjData->IconImageFile, pObjData->ToolTipText, TrayIconCB, 
   								   &(pObjData->iconHandle)));
		pObjData->iconInstalled = 1;
		
   		if (ListNumItems(pObjData->MenuItems) > 0)
   		{
   			errChk(BuildMenu(*pObjData));
   		}
   		else
   		{
			errChk(SetTrayIconMenuAttr (pObjData->iconHandle, ATTR_VISIBLE, 0));
   		}
    }
    else
    {
    	// If Icon already installed change IconImageFile and ToolTipText
	    errChk(SetTrayIconAttr (pObjData->iconHandle, ATTR_TRAY_ICOFILE, pObjData->IconImageFile));
	    errChk(SetTrayIconAttr (pObjData->iconHandle, ATTR_TRAY_TOOLTIPTEXT, pObjData->ToolTipText));
    }

Error:
    if (locked)
        CA_ServerReleaseObjData (objHandle);
    if (error < 0)
        hr = E_UNEXPECTED;
    return hr;
}

HRESULT CVIFUNC TrayIconITrayIconRemoveTrayIcon (CAServerObjHandle objHandle)
{
    int 				error = 0;
    HRESULT             hr = S_OK;
    TrayIconObjData     *pObjData = NULL;
    int                 locked = 0;

    // Get the object data.
    hrChk (CA_ServerGetObjData (objHandle, &pObjData));
    locked = 1;
    
	// Process all events before removing Icon.
	ProcessSystemEvents ();
    
    if (pObjData->iconInstalled)
    {
    	// Remove the icon from the taskbar System Tray
   		errChk(DetachTrayIconMenu(pObjData->iconHandle));
   		errChk(RemoveSysTrayIcon (pObjData->iconHandle));
		pObjData->iconHandle = 0;
		pObjData->iconInstalled = 0;
    }

Error:
    if (locked)
        CA_ServerReleaseObjData (objHandle);
    if (error < 0)
        hr = E_UNEXPECTED;
    return hr;
}


HRESULT CVIFUNC TrayIconITrayIconget_IconImageFile (CAServerObjHandle objHandle,
                                                    char ** IconImageFile)
{
    HRESULT             hr = S_OK;
    TrayIconObjData     *pObjData = NULL;
    int                 locked = 0;

    // Get the object data.
    hrChk (CA_ServerGetObjData (objHandle, &pObjData));
    locked = 1;
    *IconImageFile = dupStr(pObjData->IconImageFile);

Error:
    if (locked)
        CA_ServerReleaseObjData (objHandle);
    return hr;
}
                                                    

HRESULT CVIFUNC TrayIconITrayIconput_IconImageFile (CAServerObjHandle objHandle,
                                                    char * IconImageFile)
{
	int					error = 0;
    HRESULT             hr = S_OK;
    TrayIconObjData     *pObjData = NULL;
    int                 locked = 0;

    // Get the object data.
    hrChk (CA_ServerGetObjData (objHandle, &pObjData));
    locked = 1;
    pObjData->IconImageFile = dupStr(IconImageFile);
    
    if (pObjData->iconInstalled)
    {
	    errChk(SetTrayIconAttr (pObjData->iconHandle, ATTR_TRAY_ICOFILE, IconImageFile));
    }

Error:
    if (locked)
        CA_ServerReleaseObjData (objHandle);
    if (error < 0)
        hr = E_UNEXPECTED;
    return hr;
}


HRESULT CVIFUNC TrayIconITrayIconget_ToolTipText (CAServerObjHandle objHandle,
                                                  char ** ToolTipText)
{
    HRESULT             hr = S_OK;
    TrayIconObjData     *pObjData = NULL;
    int                 locked = 0;

    // Get the object data.
    hrChk (CA_ServerGetObjData (objHandle, &pObjData));
    locked = 1;
    *ToolTipText = dupStr(pObjData->ToolTipText);

Error:
    if (locked)
        CA_ServerReleaseObjData (objHandle);
    return hr;
}


HRESULT CVIFUNC TrayIconITrayIconput_ToolTipText (CAServerObjHandle objHandle,
                                                  char * ToolTipText)
{
	int					error = 0;
    HRESULT             hr = S_OK;
    TrayIconObjData     *pObjData = NULL;
    int                 locked = 0;

    // Get the object data.
    hrChk (CA_ServerGetObjData (objHandle, &pObjData));
    locked = 1;
    pObjData->ToolTipText = dupStr(ToolTipText);
    
    if (pObjData->iconInstalled)
    {
	    errChk(SetTrayIconAttr (pObjData->iconHandle, ATTR_TRAY_TOOLTIPTEXT, ToolTipText));
    }

Error:
    if (locked)
        CA_ServerReleaseObjData (objHandle);
    if (error < 0)
        hr = E_UNEXPECTED;
    return hr;
}

HRESULT CVIFUNC TrayIconITrayIconget_DefaultMenuItem (CAServerObjHandle objHandle,
                                                      long* DefaultMenuItem)
{
    int 				error = 0;
    HRESULT             hr = S_OK;
    TrayIconObjData     *pObjData = NULL;
    int                 locked = 0;

    // Get the object data.
    hrChk (CA_ServerGetObjData (objHandle, &pObjData));
    locked = 1;
    
    // Make interface index 0 based
    *DefaultMenuItem = pObjData->defaultMenuItem - 1;

Error:
    if (locked)
        CA_ServerReleaseObjData (objHandle);
    if (error < 0)
        hr = E_UNEXPECTED;
    return hr;
}

HRESULT CVIFUNC TrayIconITrayIconput_DefaultMenuItem (CAServerObjHandle objHandle,
                                                      long DefaultMenuItem)
{
    int 				error = 0;
    HRESULT             hr = S_OK;
    TrayIconObjData     *pObjData = NULL;
    int                 locked = 0;

    // Get the object data.
    hrChk (CA_ServerGetObjData (objHandle, &pObjData));
    locked = 1;
    
    // Make interface index 0 based
    pObjData->defaultMenuItem = DefaultMenuItem + 1;
    
    errChk(BuildMenu(*pObjData));

Error:
    if (locked)
        CA_ServerReleaseObjData (objHandle);
    if (error < 0)
        hr = E_UNEXPECTED;
    return hr;
}
                                                       
HRESULT CVIFUNC TrayIconITrayIconget_MenuVisable (CAServerObjHandle objHandle,
                                                  VARIANT_BOOL* MenuVisable)
{
    int 				error = 0;
    HRESULT             hr = S_OK;
    TrayIconObjData     *pObjData = NULL;
    int                 locked = 0;

    // Get the object data.
    hrChk (CA_ServerGetObjData (objHandle, &pObjData));
    locked = 1;

	*MenuVisable = pObjData->menuVisable;	

Error:
    if (locked)
        CA_ServerReleaseObjData (objHandle);
    if (error < 0)
        hr = E_UNEXPECTED;
    return hr;
}
                                                        
HRESULT CVIFUNC TrayIconITrayIconput_MenuVisable (CAServerObjHandle objHandle,
                                                  VARIANT_BOOL MenuVisable)
{
    int 				error = 0;
    HRESULT             hr = S_OK;
    TrayIconObjData     *pObjData = NULL;
    int                 locked = 0;
    
    // Get the object data.
    hrChk (CA_ServerGetObjData (objHandle, &pObjData));
    locked = 1;

	pObjData->menuVisable = MenuVisable;
	errChk(BuildMenu(*pObjData));

Error:
    if (locked)
        CA_ServerReleaseObjData (objHandle);
    if (error < 0)
        hr = E_UNEXPECTED;
    return hr;
}

HRESULT CVIFUNC TrayIconITrayIconAddMenuItem (CAServerObjHandle objHandle,
                                              char * Name, VARIANT_BOOL Dimmed,
                                              VARIANT_BOOL Checked)
{
    int 				error = 0;
    HRESULT             hr = S_OK;
    TrayIconObjData     *pObjData = NULL;
    int                 locked = 0;
    TrayIconMenuItem 	item;
    
	item.Name = dupStr(Name);
    item.Dimmed = Dimmed;
    item.Checked = Checked;
    
    // Get the object data.
    hrChk (CA_ServerGetObjData (objHandle, &pObjData));
    locked = 1;
	errChk(ListInsertItem (pObjData->MenuItems, &item, END_OF_LIST));
	
	// Update current Menu.
	errChk(BuildMenu(*pObjData));

Error:
    if (locked)
        CA_ServerReleaseObjData (objHandle);
    if (error < 0)
        hr = E_UNEXPECTED;
    return hr;
}
                                               

HRESULT CVIFUNC TrayIconITrayIconDeleteMenuItem (CAServerObjHandle objHandle,
                                                 short Index)
{
    int 				error = 0;
    HRESULT             hr = S_OK;
    TrayIconObjData     *pObjData = NULL;
    int                 locked = 0;
    
    // Get the object data.
    hrChk (CA_ServerGetObjData (objHandle, &pObjData));
    locked = 1;
    
    // Make interface index 0 based
	ListRemoveItem (pObjData->MenuItems, 0, Index + 1);
	
	// Update current Menu.
	errChk(BuildMenu(*pObjData));

Error:
    if (locked)
        CA_ServerReleaseObjData (objHandle);
    if (error < 0)
        hr = E_UNEXPECTED;
    return hr;
}

HRESULT CVIFUNC TrayIconITrayIconGetMenuItem (CAServerObjHandle objHandle,
                                              short Index, char ** Name,
                                              VARIANT_BOOL* Dimmed,
                                              VARIANT_BOOL* Checked)
{
    int 				error = 0;
    HRESULT             hr = S_OK;
    TrayIconObjData     *pObjData = NULL;
    int                 locked = 0;
    TrayIconMenuItem 	item;
    
    // Get the object data.
    hrChk (CA_ServerGetObjData (objHandle, &pObjData));
    locked = 1;
    
    // Make interface index 0 based
	ListGetItem (pObjData->MenuItems, &item, Index + 1);
	
	*Name = malloc (sizeof(char) * (strlen(item.Name) + 1));
	strcpy(*Name, item.Name);
	
	*Name = dupStr(item.Name);
	*Dimmed = item.Dimmed;
	*Checked = item.Checked;

Error:
    if (locked)
        CA_ServerReleaseObjData (objHandle);
    if (error < 0)
        hr = E_UNEXPECTED;
    return hr;
}
                                               
                                               

HRESULT CVIFUNC TrayIconITrayIconReplaceMenuItem (CAServerObjHandle objHandle,
                                                  short Index, char * Name,
                                                  VARIANT_BOOL Dimmed,
                                                  VARIANT_BOOL Checked)
{
    int 				error = 0;
    HRESULT             hr = S_OK;
    TrayIconObjData     *pObjData = NULL;
    int                 locked = 0;
    TrayIconMenuItem 	item;

	item.Name = dupStr(Name);
    item.Dimmed = Dimmed;
    item.Checked = Checked;
    
    // Get the object data.
    hrChk (CA_ServerGetObjData (objHandle, &pObjData));
    locked = 1;
	
	// Make interface index 0 based
	ListReplaceItem (pObjData->MenuItems, &item, Index + 1);
	
	// Update current Menu.
	errChk(BuildMenu(*pObjData));

Error:
    if (locked)
        CA_ServerReleaseObjData (objHandle);
    if (error < 0)
        hr = E_UNEXPECTED;
    return hr;
}

HRESULT CVIFUNC TrayIconITrayIconget_NumberOfMenuItems (CAServerObjHandle objHandle,
                                                        short* NumberOfMenuItems)
{
    int 				error = 0;
    HRESULT             hr = S_OK;
    TrayIconObjData     *pObjData = NULL;
    int                 locked = 0;
    
    // Get the object data.
    hrChk (CA_ServerGetObjData (objHandle, &pObjData));
    locked = 1;
	*NumberOfMenuItems = ListNumItems (pObjData->MenuItems);
	
Error:
    if (locked)
        CA_ServerReleaseObjData (objHandle);
    if (error < 0)
        hr = E_UNEXPECTED;
    return hr;
}
