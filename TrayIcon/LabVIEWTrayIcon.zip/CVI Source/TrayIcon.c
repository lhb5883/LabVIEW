/*****************************************************************************/
/* Includes                                                                  */
/*****************************************************************************/
#include "TrayIconActiveXServer_axs.h"
#include <utility.h>
#include "toolbox.h"
#include <cvirte.h>
#include <userint.h>

/*****************************************************************************/
/* Macros                                                                    */
/*****************************************************************************/
#define hrChk(fCall) if (hr = (fCall), FAILED (hr)) goto Error; else

/*****************************************************************************/
/* Type definitions                                                          */
/*****************************************************************************/
typedef struct TrayIconObjData_ {
	int iconHandle;
	int iconInstalled;
} TrayIconObjData;


/*****************************************************************************/
/* Global variables                                                          */
/*****************************************************************************/
static ListType     gObjList = 0;       // List holding all server objects
static int          gObjListLock = 0;   // Lock for object list


/******************************************************************************/
/* ActiveX server's WinMain function                      				      */
/******************************************************************************/
int __stdcall WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                       LPSTR lpszCmdLine, int nCmdShow)
{
	// Variables for error checking macros: errChk, nullChk and hrChk
	int 	   error = 0;
    HRESULT    hr = S_OK;
	
	// Local Variables
	int        runServer = 0;		// Server Running Flag
	char       errBuf [500] = {0};  // Error buffer
	int        initedServer = 0;    // Server created flag

	nullChk (InitCVIRTE (hInstance, 0, 0))

    // Intialize locks and data structures
    errChk (CmtNewLock ("", 0, &gObjListLock));
    nullChk (gObjList = ListCreate (sizeof (CAServerObjHandle)));
    
	// ActiveX server initialization
	hrChk (CaSrvrTrayIconServerInit (hInstance, lpszCmdLine, &runServer, errBuf, 
							   		 sizeof(errBuf)));
    initedServer = 1;

	if (runServer)
	{
		errChk (RunUserInterface ());	// Process messages
	}

Error:
	// ActiveX server cleanup
    if (initedServer)
		CaSrvrTrayIconServerUninit (hInstance);
    
    // Discard List Lock
    if (gObjListLock)
        CmtDiscardLock (gObjListLock);
    
    // Dispose Server Object List
    if (gObjList)
        ListDispose (gObjList);
    
    // Set error if windows error occured.
    if (FAILED (hr))
        error = -1;

	return error;
}

/******************************************************************************/
/* ActiveX Object Callback Function(s)                                        */
/*                                                                            */
/* Events:                                                                    */
/* 1) CA_SERVER_EVENT_OBJECT_CREATE                                           */
/* 2) CA_SERVER_EVENT_OBJECT_DESTROY                                          */
/******************************************************************************/

HRESULT CVIFUNC TrayIconObjectCB (CAServerObjHandle objHandle,
                                  const CLSID *pClsid, int event,
                                  void *callbackData)
{
	// Variables for error checking macros: errChk, nullChk and hrChk
	int 	   error = 0;
    HRESULT    hr = S_OK;
    
	// Local Variables
    TrayIconObjData   *pObjData = NULL;
    int               objIndex;
	int 			  locked = 0;

switch (event)
	{
	case CA_SERVER_EVENT_OBJECT_CREATE:
        
        // Allocate object data
        nullChk (pObjData = calloc (1, sizeof (TrayIconObjData)));
        hrChk (CA_ServerSetObjData (objHandle, pObjData));
        
        // Store the object in object list
        errChk (CmtGetLock (gObjListLock));
        locked = 1;
        nullChk (ListInsertItem (gObjList, &objHandle, END_OF_LIST));
        pObjData = NULL;
        
		break;
	case CA_SERVER_EVENT_OBJECT_DESTROY:
        
        // Get the object data and dispose it
        hrChk (CA_ServerGetObjData (objHandle, &pObjData));
        if (pObjData) free (pObjData);
        hrChk (CA_ServerReleaseObjData (objHandle));
        
        // Remove the object from the object list
        errChk (CmtGetLock (gObjListLock));
        locked = 1;
        objIndex = ListFindItem (gObjList, &objHandle, FRONT_OF_LIST, IntCompare);
        if (objIndex) ListRemoveItem (gObjList, NULL, objIndex);
		
		break;
	default:
		
		break;
	}

Error:
    if (locked)
        CmtReleaseLock (gObjListLock);
    if (error < 0)
        hr = E_UNEXPECTED;
    return hr;
}
