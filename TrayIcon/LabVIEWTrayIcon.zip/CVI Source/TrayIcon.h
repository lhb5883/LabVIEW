/*****************************************************************************/
/* Includes                                                                  */
/*****************************************************************************/
#include "TrayIconActiveXServer_axs.h"
#include <utility.h>
#include "toolbox.h"
#include <cvirte.h>
#include <userint.h>

/*****************************************************************************/
/* Macros                                                                    */
/*****************************************************************************/
#define hrChk(fCall) if (hr = (fCall), FAILED (hr)) goto Error; else

/*****************************************************************************/
/* Type definitions                                                          */
/*****************************************************************************/
typedef struct TrayIconMenuItem_ {
	char		*Name;
	int			Dimmed;
	int			Checked;
} TrayIconMenuItem;

typedef struct TrayIconObjData_ {
	int			iconHandle;
	int  		iconInstalled;
	char 		*IconImageFile;
	char		*ToolTipText;
	int			menuVisable;
	int			defaultMenuItem;
	ListType	MenuItems;
} TrayIconObjData;

/*****************************************************************************/
/* Global variables                                                          */
/*****************************************************************************/
static int 			panelHandle;
static ListType     gObjList = 0;       // List holding all server objects
static int          gObjListLock = 0;   // Lock for object list

/*****************************************************************************/
/* Callback Functions                                                        */
/*****************************************************************************/
int CVICALLBACK TrayIconCB (int iconHandle, int event, int eventData);

/*****************************************************************************/
/* Functions                                                                 */
/*****************************************************************************/
int BuildMenu(TrayIconObjData objData);
char *dupStr(char *str);
