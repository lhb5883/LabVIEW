LabVIEW Tray Icon Example v1.0 Karsten van Zwol, 2004

This example contains a ActiveX Server with a easy to use Interface and 
LabVIEW VI's to create and control a Icon in the Windows System Tray Area.

The ActiveX Server is created with LabWindows/CVI and Source Code is included. 
But LabWindows/CVI is not required to use this example with LabVIEW. If needed 
you can use this Source code to make modifications to the Server. In this case 
you will need LabWindows/CVI.

Installation:
- Extract all Files 
- run setup.exe, 
  this will install and register the Tray Icon ActiveX server with Windows, and
  insall the LabVIEW VI to the <LabVIEW folder>\User.lib folder.
- Start LabVIEW and open the 'LabVIEW Tray Example.vi' 
  from the Functions Palette -> All Functions -> User Library -> Tray Icon Palette.